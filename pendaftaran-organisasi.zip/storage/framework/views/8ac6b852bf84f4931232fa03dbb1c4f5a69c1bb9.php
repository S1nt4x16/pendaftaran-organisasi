<?php if($message = Session::get('error')): ?>
<div class="alert d alert-danger alert-block">
        <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
<div class="alert s alert-success alert-block">
        <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>

<style>
    .d {
        font-size: 20px;
        font-family: courier new;
        color:red;
        background-color:black;
    }
    .s {
        font-size: 20px;
        font-family: courier new;
        color:green;
        background-color:black;
    }
</style><?php /**PATH D:\C\coding\pendaftaran-organisasi\resources\views/layouts/message.blade.php ENDPATH**/ ?>