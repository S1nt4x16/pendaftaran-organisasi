<script 
    src="{{ asset('responsive/res/js/dataTables.responsive.min.js') }}">
</script>
