<link rel="stylesheet" 
    href="{{ asset('responsive/res/css/responsive.dataTables.min.css') }}">
    