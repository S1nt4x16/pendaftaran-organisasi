import {Chart, registerables} from '../dist/chart.mjs';

Chart.register(...registerables);

export default Chart;
