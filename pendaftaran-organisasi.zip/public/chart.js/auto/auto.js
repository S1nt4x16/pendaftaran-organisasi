module.exports = require('../dist/chart');
